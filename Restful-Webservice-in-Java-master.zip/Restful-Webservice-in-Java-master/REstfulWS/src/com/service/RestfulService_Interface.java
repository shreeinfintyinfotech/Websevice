package com.service;

public interface RestfulService_Interface {

	String addStudent(String student);
	String updateStudent(String student);
	String deleteStudent(int id);
	String viewAllStudents();
	
}
