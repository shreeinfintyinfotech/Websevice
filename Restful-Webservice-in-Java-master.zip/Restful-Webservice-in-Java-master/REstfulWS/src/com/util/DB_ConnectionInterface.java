package com.util;

import java.sql.Connection;

public interface DB_ConnectionInterface {

	public Connection getConnection();
	
}
